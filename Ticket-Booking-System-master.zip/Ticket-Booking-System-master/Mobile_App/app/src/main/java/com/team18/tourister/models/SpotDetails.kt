package com.team18.tourister.models

data class SpotDetails(var T_Image: String, var T_description: String, var T_name: String, var Spots: List<SpotPlace>)