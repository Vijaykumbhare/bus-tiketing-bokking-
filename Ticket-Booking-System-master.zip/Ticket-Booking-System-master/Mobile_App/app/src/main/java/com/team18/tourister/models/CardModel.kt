package com.team18.tourister.models

data class CardModel(var Card: String,var Expiry: String, var Name: String, var Email: String)