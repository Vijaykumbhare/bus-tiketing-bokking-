package com.team18.tourister.models

data class SearchModel(var Cities: List<CityPlace>, var Spots: List<SpotPlace>)