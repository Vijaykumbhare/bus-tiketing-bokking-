package com.team18.tourister.models

data class SearchListModel(var name: String, var description: String, var type: String, var image_url: String)