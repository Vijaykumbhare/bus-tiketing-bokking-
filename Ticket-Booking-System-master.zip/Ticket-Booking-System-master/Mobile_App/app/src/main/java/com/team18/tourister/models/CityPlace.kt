package com.team18.tourister.models

data class CityPlace(var Place_name: String, var Place_description: String, var Place_Image: String)