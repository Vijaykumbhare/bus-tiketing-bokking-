package com.team18.tourister.models

data class SpotPlace (var T_Image: String, var T_description: String, var T_name: String)