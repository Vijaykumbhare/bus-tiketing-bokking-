package com.team18.tourister.models

data class AuthenticationModel(var message: String, var token: String)