# Ticket-Booking-System

## Product
Android application(Kotlin) and Web application(React) to book the bus ticket to searched destination. 

## API
REST APIs were developed using flask(Python), dockerized and deployed on the AWS.

## Technology Stack
- Database : DynamoDb
- AWS services : EC2 instance, ECR, ECS

## Developed By
- Poojan Patel
- Karthikk Tamil
- Tobi Agbola
- Sohail Mohammed
